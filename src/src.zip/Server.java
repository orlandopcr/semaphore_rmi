import sun.security.util.Length;

import java.rmi.AlreadyBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

public class Server {

    public static void main(String[] args) throws RemoteException, AlreadyBoundException {


        ArrayList<Integer> nodos = new ArrayList();
        ArrayList<Integer> req = new ArrayList();
        ArrayList<Integer> last = new ArrayList();

        Remote stub = UnicastRemoteObject.exportObject(new TestRemote() {
            @Override
            public String sayHello(String name) throws RemoteException {
                return "Hello, " + name;
            }

            @Override
            public int loginRed(String id, String total) throws RemoteException {

                int id_entero = Integer.parseInt(id);
                int total_entero = Integer.parseInt(total);
                nodos.add(id_entero);

                if (nodos.size()== total_entero){

                    for (int i = 0 ; i < total_entero; i = i+1){
                        req.add(0);

                    }
                    for (int i = 0 ; i < total_entero; i = i+1){
                        last.add(0);
                    }
                    System.out.println("req:  " + req);
                    System.out.println("last:  "+ last);

                }

                return id_entero;
            }
        }, 0);



        Registry registry = LocateRegistry.createRegistry(Registry.REGISTRY_PORT);
        registry.bind("Test", stub);

    }

}